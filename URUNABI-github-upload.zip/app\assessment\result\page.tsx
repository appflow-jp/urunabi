"use client";

import Link from "next/link";
import { Suspense, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  Copy,
  Download,
  ImageDown,
  Instagram,
  MessageCircle,
  TrendingUp,
  Trophy
} from "lucide-react";
import { toPng } from "html-to-image";
import { BrandHeader } from "@/components/brand-header";
import { buttonClassName } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  calculateAssessment,
  formatYen,
  type AssessmentInput
} from "@/lib/valuation";

function ResultContent() {
  const searchParams = useSearchParams();
  const recordCardRef = useRef<HTMLDivElement>(null);
  const [copyMessage, setCopyMessage] = useState("");
  const input: AssessmentInput = {
    model: searchParams.get("model") ?? "",
    year: searchParams.get("year") ?? "",
    mileage: searchParams.get("mileage") ?? "",
    custom: searchParams.get("custom") ?? "",
    price: searchParams.get("price") ?? ""
  };
  const result = calculateAssessment(input);
  const recordText = useMemo(
    () =>
      [
        "URUNABI 査定控え",
        "",
        `車種: ${input.model || "-"}`,
        `年式: ${input.year || "-"}`,
        `走行距離: ${input.mileage || "-"}`,
        `カスタム内容: ${input.custom || "なし / 未入力"}`,
        `希望売却価格: ${input.price || "-"}`,
        "",
        `市場参考価格: ${formatYen(result.marketValue)}`,
        `買取予想: ${formatYen(result.buyoutValue)}`,
        `委託販売予想: ${formatYen(result.consignmentValue)}`,
        `委託販売の差額目安: +${formatYen(result.difference)}`,
        "",
        "算出メモ:",
        ...result.notes.map((note) => `- ${note}`)
      ].join("\n"),
    [input.custom, input.mileage, input.model, input.price, input.year, result]
  );

  async function handleCopyRecord() {
    await navigator.clipboard.writeText(recordText);
    setCopyMessage("査定控えをコピーしました。");
  }

  function handleDownloadRecord() {
    const blob = new Blob([recordText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "urunabi-assessment.txt";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  async function handleDownloadImage() {
    if (!recordCardRef.current) {
      return;
    }

    const dataUrl = await toPng(recordCardRef.current, {
      cacheBust: true,
      pixelRatio: 2,
      backgroundColor: "#050505"
    });
    const anchor = document.createElement("a");
    anchor.href = dataUrl;
    anchor.download = "urunabi-assessment.png";
    anchor.click();
  }

  const results = [
    { label: "市場参考価格", value: formatYen(result.marketValue), tone: "market" },
    { label: "買取予想", value: formatYen(result.buyoutValue), tone: "muted" },
    {
      label: "委託販売予想",
      value: formatYen(result.consignmentValue),
      tone: "strong"
    }
  ];

  return (
    <main className="mx-auto min-h-screen w-full max-w-2xl px-5 pb-10">
      <BrandHeader />
      <section>
        <div className="mb-7">
          <p className="text-xs font-bold tracking-[0.22em] text-garage-gold">
            MARKET ESTIMATE
          </p>
          <h1 className="mt-3 text-3xl font-black text-white">査定結果</h1>
          <p className="mt-3 leading-7 text-garage-steel">
            入力された車両情報をもとに、市場参考価格と売却方法ごとの予想価格を算出しました。
          </p>
        </div>

        <Card className="mb-4">
          <CardContent>
            <p className="text-xs font-bold tracking-[0.16em] text-garage-gold">
              VEHICLE
            </p>
            <h2 className="mt-2 text-2xl font-black text-white">
              {input.model || "車種未入力"}
            </h2>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-garage-steel">年式</dt>
                <dd className="mt-1 font-bold text-garage-ivory">
                  {input.year || "-"}
                </dd>
              </div>
              <div>
                <dt className="text-garage-steel">走行距離</dt>
                <dd className="mt-1 font-bold text-garage-ivory">
                  {input.mileage || "-"}
                </dd>
              </div>
              <div className="col-span-2">
                <dt className="text-garage-steel">カスタム内容</dt>
                <dd className="mt-1 font-bold text-garage-ivory">
                  {input.custom || "なし / 未入力"}
                </dd>
              </div>
            </dl>
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-3">
          {results.map((item) => (
            <Card
              key={item.label}
              className={
                item.tone === "strong"
                  ? "border-garage-gold/70 bg-garage-gold/10 sm:col-span-1"
                  : item.tone === "market"
                    ? "border-white/20 bg-white/[0.07] sm:col-span-1"
                    : ""
              }
            >
              <CardContent>
                <p className="text-sm font-bold tracking-[0.14em] text-garage-steel">
                  {item.label}
                </p>
                <p
                  className={
                    item.tone === "strong"
                      ? "mt-4 text-3xl font-black text-garage-gold"
                      : "mt-4 text-2xl font-black text-white"
                  }
                >
                  {item.value}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="mt-4 border-garage-gold/80 bg-gradient-to-br from-garage-gold/20 to-white/[0.04]">
          <CardContent className="flex items-center gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-garage-gold text-black">
              <TrendingUp className="h-7 w-7" />
            </div>
            <div>
              <p className="text-sm font-bold tracking-[0.14em] text-garage-steel">
                委託販売の差額目安
              </p>
              <p className="mt-1 text-2xl font-black text-garage-gold sm:text-3xl">
                +{formatYen(result.difference)} 高く売れる可能性
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-4">
          <CardContent>
            <p className="text-sm font-bold tracking-[0.14em] text-garage-steel">
              算出メモ
            </p>
            <ul className="mt-3 space-y-2 text-sm leading-6 text-garage-ivory">
              {result.notes.map((note) => (
                <li key={note}>・{note}</li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <div ref={recordCardRef} className="mt-4">
          <Card className="border-white/15 bg-white/[0.05]">
            <CardContent>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-bold tracking-[0.14em] text-garage-steel">
                  保存用の査定控え
                </p>
                <p className="mt-2 text-sm leading-6 text-garage-ivory">
                  入力内容と査定結果をまとめて残せます。
                </p>
              </div>
              {copyMessage ? (
                <p className="text-xs font-bold text-garage-gold">{copyMessage}</p>
              ) : null}
            </div>

            <pre className="mt-4 max-h-80 overflow-auto whitespace-pre-wrap rounded-md border border-white/10 bg-black/35 p-4 text-sm leading-6 text-garage-ivory">
              {recordText}
            </pre>

            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <button
                type="button"
                onClick={handleCopyRecord}
                className={buttonClassName({ variant: "outline", className: "gap-3" })}
              >
                控えをコピー
                <Copy className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={handleDownloadRecord}
                className={buttonClassName({ variant: "secondary", className: "gap-3" })}
              >
                テキスト保存
                <Download className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={handleDownloadImage}
                className={buttonClassName({ className: "gap-3" })}
              >
                画像で保存
                <ImageDown className="h-5 w-5" />
              </button>
            </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 space-y-4">
          <a
            href="https://lin.ee/zBWaJiv"
            className={buttonClassName({ className: "gap-3" })}
          >
            LINEで相談する
            <MessageCircle className="h-5 w-5" />
          </a>
          <Link
            href="/sales"
            className={buttonClassName({ variant: "outline", className: "gap-3" })}
          >
            販売実績を見る
            <Trophy className="h-5 w-5" />
          </Link>
          <a
            href="https://www.instagram.com/therusty_garage?igsh=MWFhYXVjMGlpOWp5YQ%3D%3D&utm_source=qr"
            className={buttonClassName({ variant: "outline", className: "gap-3" })}
          >
            Instagramで相談する
            <Instagram className="h-5 w-5" />
          </a>
          <Link href="/" className={buttonClassName({ variant: "secondary" })}>
            トップに戻る
          </Link>
        </div>
      </section>
    </main>
  );
}

export default function ResultPage() {
  return (
    <Suspense
      fallback={
        <main className="mx-auto min-h-screen w-full max-w-2xl px-5 pb-10">
          <BrandHeader />
          <section>
            <Card>
              <CardContent>
                <p className="text-sm font-bold tracking-[0.14em] text-garage-steel">
                  査定結果を計算しています...
                </p>
              </CardContent>
            </Card>
          </section>
        </main>
      }
    >
      <ResultContent />
    </Suspense>
  );
}
