import nodemailer from "nodemailer";
import { NextResponse } from "next/server";

type AssessmentPayload = {
  model?: string;
  year?: string;
  mileage?: string;
  custom?: string;
  price?: string;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as AssessmentPayload;
    const smtpUser = process.env.GMAIL_SMTP_USER;
    const smtpPass = process.env.GMAIL_APP_PASSWORD;
    const destination = process.env.CONTACT_TO_EMAIL ?? "tyomotyomo1017@gmail.com";

    if (!smtpUser || !smtpPass) {
      return NextResponse.json(
        { error: "Email service is not configured." },
        { status: 500 }
      );
    }

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: smtpUser,
        pass: smtpPass
      }
    });

    await transporter.sendMail({
      from: `"URUNABI" <${smtpUser}>`,
      to: destination,
      subject: "【URUNABI】新しい査定フォーム送信",
      text: [
        "URUNABIの査定フォームが送信されました。",
        "",
        `車種: ${body.model ?? ""}`,
        `年式: ${body.year ?? ""}`,
        `走行距離: ${body.mileage ?? ""}`,
        `カスタム内容: ${body.custom ?? ""}`,
        `希望売却価格: ${body.price ?? ""}`
      ].join("\n")
    });

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: "Failed to send assessment email." },
      { status: 500 }
    );
  }
}
