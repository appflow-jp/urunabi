import Link from "next/link";
import { Bike, Trophy } from "lucide-react";
import { BrandHeader } from "@/components/brand-header";
import { buttonClassName } from "@/components/ui/button";

const sales = [
  { model: "HONDA MAGNA50", image: "/sales/IMG_5150.jpg" },
  { model: "SUZUKI GS50", image: "/sales/IMG_5151.jpg" },
  { model: "Yamaha YZF-R25", image: "/sales/IMG_5152.jpg" },
  { model: "Yamaha Mint", image: "/sales/IMG_5154.jpg" },
  { model: "Suzuki Let's 2", image: "/sales/IMG_5155.jpg" },
  { model: "Honda Z50", image: "/sales/IMG_5156.jpg" },
  { model: "Honda AF16", image: "/sales/IMG_5157.jpg" },
  { model: "SUZUKI Let's2 pallet", image: "/sales/IMG_5158.jpg" },
  { model: "YAMAHA VINO", image: "/sales/IMG_5159.jpg" },
  { model: "HONDA CREA SCOOPY", image: "/sales/IMG_5160.jpg" },
  { model: "HONDA V-TWIN MAGNA 1999", image: "/sales/IMG_5161.jpg" },
  { model: "KAWASAKI ELIMINATOR250LX 1993", image: "/sales/IMG_5162.jpg" },
  { model: "SUZUKI Grasstracker 250 2000", image: "/sales/IMG_5163.jpg" },
  { model: "SUZUKI GSX-R1100 1993", image: "/sales/IMG_5164.jpg" },
  { model: "YAMAHA XV250 1987", image: "/sales/IMG_5165.jpg" },
  { model: "KAWASAKI ELIMINATOR125 1999", image: "/sales/IMG_5166.jpg" },
  { model: "HONDA MC13 1985", image: "/sales/IMG_5167.jpg" },
  { model: "YAMAHA XV250 1994", image: "/sales/IMG_5168.jpg" },
  { model: "HONDA GB250 1983", image: "/sales/IMG_5169.jpg" }
];

export default function SalesPage() {
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 pb-10">
      <BrandHeader />
      <section>
        <div className="mx-auto mb-8 max-w-3xl text-center">
          <p className="inline-flex items-center gap-2 text-xs font-bold tracking-[0.22em] text-garage-gold">
            <Trophy className="h-4 w-4" />
            SOLD OUT ARCHIVE
          </p>
          <h1 className="mt-4 text-4xl font-black leading-tight text-white sm:text-6xl">
            売却実績
          </h1>
          <p className="mt-4 leading-8 text-garage-steel">
            実際の販売実績画像をもとにしたアーカイブです。車両名と写真だけで、THE RUSTY GARAGEらしい空気感が伝わるようにまとめました。
          </p>
        </div>

        <div className="mb-6 rounded-lg border border-white/10 bg-white/[0.04] p-4">
          <p className="flex items-center gap-2 text-xs font-bold tracking-[0.16em] text-garage-steel">
            <Bike className="h-4 w-4 text-garage-gold" />
            CONSIGNMENT RECORDS
          </p>
          <p className="mt-2 text-xl font-black text-white">
            原付から旧車、アメリカン、スポーツまで幅広く掲載
          </p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {sales.map((sale, index) => (
            <article
              key={sale.model}
              className={
                index === 0
                  ? "group overflow-hidden rounded-lg border border-garage-gold/60 bg-white/[0.04] shadow-glow sm:col-span-2"
                  : "group overflow-hidden rounded-lg border border-white/10 bg-white/[0.04]"
              }
            >
              <div className="relative aspect-square overflow-hidden bg-black">
                <img
                  src={sale.image}
                  alt={`${sale.model} 売却実績`}
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
                <span className="absolute left-4 top-4 rounded-md bg-red-600 px-3 py-1 text-xs font-black tracking-[0.18em] text-white">
                  SOLD OUT
                </span>
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <p className="text-xs font-bold tracking-[0.16em] text-garage-gold">
                    THE RUSTY GARAGE
                  </p>
                  <h2 className="mt-2 text-2xl font-black leading-tight text-white">
                    {sale.model}
                  </h2>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="mx-auto mt-8 max-w-2xl space-y-4">
          <Link href="/assessment" className={buttonClassName()}>
            無料で査定する
          </Link>
          <Link href="/" className={buttonClassName({ variant: "outline" })}>
            トップに戻る
          </Link>
        </div>
      </section>
    </main>
  );
}
