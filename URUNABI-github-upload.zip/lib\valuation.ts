export type AssessmentInput = {
  model: string;
  year: string;
  mileage: string;
  custom: string;
  price: string;
};

export type AssessmentResult = {
  marketValue: number;
  buyoutValue: number;
  consignmentValue: number;
  difference: number;
  confidence: "LOW" | "STANDARD" | "HIGH";
  notes: string[];
};

const categoryBases = [
  {
    keywords: ["harley", "xl", "davidson", "magna", "dragstar", "xv", "eliminator"],
    base: 260000,
    note: "アメリカン系は雰囲気やカスタムの相性で委託販売向きです。"
  },
  {
    keywords: ["r25", "yzf", "gsx", "ninja", "cbr", "sport"],
    base: 330000,
    note: "スポーツ系は年式と外装状態で市場価格が動きやすい車種です。"
  },
  {
    keywords: ["sr", "gb", "grass", "tracker", "z50", "monkey"],
    base: 300000,
    note: "旧車・ネオクラシック系は探している買い手に届くと価格が伸びやすい傾向です。"
  },
  {
    keywords: ["vino", "scoopy", "mint", "let", "af", "crea", "50", "gs50"],
    base: 110000,
    note: "原付クラスは状態と見た目の分かりやすさが価格に直結します。"
  }
];

function parseNumber(value: string) {
  const parsed = Number(value.replace(/[^\d]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function roundToTenThousand(value: number) {
  return Math.max(30000, Math.round(value / 10000) * 10000);
}

export function formatYen(value: number) {
  return `${value.toLocaleString("ja-JP")}円`;
}

export function calculateAssessment(input: AssessmentInput): AssessmentResult {
  const normalizedModel = input.model.toLowerCase();
  const matchedCategory =
    categoryBases.find((category) =>
      category.keywords.some((keyword) => normalizedModel.includes(keyword))
    ) ?? categoryBases[3];

  const currentYear = new Date().getFullYear();
  const year = parseNumber(input.year);
  const age = year > 1900 ? Math.max(0, currentYear - year) : 12;
  const mileage = parseNumber(input.mileage);
  const desiredPrice = parseNumber(input.price);
  const customText = input.custom.trim();

  const ageMultiplier = Math.max(0.58, 1 - age * 0.035);
  const mileageMultiplier = Math.max(0.62, 1 - mileage / 180000);
  const customMultiplier = customText.length > 0 ? 1.06 : 1;
  const desiredPriceAnchor =
    desiredPrice > 0 ? Math.min(desiredPrice, matchedCategory.base * 1.45) * 0.12 : 0;

  const rawMarketValue =
    matchedCategory.base * ageMultiplier * mileageMultiplier * customMultiplier +
    desiredPriceAnchor;
  const marketValue = roundToTenThousand(rawMarketValue);
  const buyoutValue = roundToTenThousand(marketValue * 0.72);
  const consignmentValue = roundToTenThousand(marketValue * 0.95);
  const difference = consignmentValue - buyoutValue;

  const notes = [
    matchedCategory.note,
    mileage > 30000
      ? "走行距離が多めのため、整備履歴や現車写真が価格の説得力になります。"
      : "走行距離は比較的見せやすく、写真で状態が伝わると反応を取りやすいです。",
    customText.length > 0
      ? "カスタム内容は好みが分かれるため、純正部品の有無も伝えると安心材料になります。"
      : "ノーマルに近い車両は幅広い買い手に検討されやすいです。"
  ];

  return {
    marketValue,
    buyoutValue,
    consignmentValue,
    difference,
    confidence: input.model && year > 1900 && mileage > 0 ? "STANDARD" : "LOW",
    notes
  };
}
