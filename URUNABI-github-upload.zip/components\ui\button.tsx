import * as React from "react";
import { cn } from "@/lib/utils";

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline";
}

export type ButtonVariant = "primary" | "secondary" | "outline";

const variants: Record<ButtonVariant, string> = {
  primary:
    "bg-garage-gold text-black hover:bg-garage-brass focus-visible:ring-garage-gold",
  secondary:
    "bg-white text-black hover:bg-garage-ivory focus-visible:ring-white",
  outline:
    "border border-white/15 bg-white/[0.03] text-garage-ivory hover:border-garage-gold/60 hover:bg-garage-gold/10 focus-visible:ring-garage-gold"
};

export function buttonClassName({
  variant = "primary",
  className
}: {
  variant?: ButtonVariant;
  className?: string;
} = {}) {
  return cn(
    "inline-flex min-h-14 w-full items-center justify-center rounded-md px-6 py-3 text-center text-sm font-bold tracking-[0.08em] transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-black disabled:pointer-events-none disabled:opacity-50",
    variants[variant],
    className
  );
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", ...props }, ref) => (
    <button
      ref={ref}
      className={buttonClassName({ variant, className })}
      {...props}
    />
  )
);
Button.displayName = "Button";
