export function BrandHeader() {
  return (
    <header className="px-5 pb-8 pt-9 text-center">
      <p className="text-4xl font-black tracking-[0.18em] text-white sm:text-5xl">
        URUNABI
      </p>
      <p className="mt-2 text-[0.68rem] font-semibold tracking-[0.34em] text-garage-steel">
        BY THE RUSTY GARAGE
      </p>
    </header>
  );
}
