import Link from "next/link";
import { BadgeCheck, Bike } from "lucide-react";
import { BrandHeader } from "@/components/brand-header";
import { buttonClassName } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const bikes = [
  {
    model: "Harley-Davidson XL1200X Forty-Eight",
    year: "2018年",
    mileage: "18,400km",
    price: "1,280,000円",
    sold: false
  },
  {
    model: "Triumph Bonneville T120",
    year: "2020年",
    mileage: "9,800km",
    price: "1,150,000円",
    sold: true
  },
  {
    model: "Yamaha SR400 Final Edition",
    year: "2021年",
    mileage: "6,200km",
    price: "890,000円",
    sold: false
  }
];

export default function BikesPage() {
  return (
    <main className="mx-auto min-h-screen w-full max-w-3xl px-5 pb-10">
      <BrandHeader />
      <section>
        <div className="mb-7">
          <p className="text-xs font-bold tracking-[0.22em] text-garage-gold">
            LISTINGS
          </p>
          <h1 className="mt-3 text-3xl font-black text-white">
            委託販売中バイク
          </h1>
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          {bikes.map((bike) => (
            <Card key={bike.model} className="overflow-hidden">
              <div className="relative flex aspect-[4/3] items-center justify-center bg-gradient-to-br from-zinc-900 to-black">
                <Bike className="h-16 w-16 text-garage-gold/70" />
                <span
                  className={
                    bike.sold
                      ? "absolute right-3 top-3 rounded-md bg-white px-3 py-1 text-xs font-black tracking-[0.14em] text-black"
                      : "absolute right-3 top-3 rounded-md bg-garage-gold px-3 py-1 text-xs font-black tracking-[0.14em] text-black"
                  }
                >
                  {bike.sold ? "SOLD" : "ON SALE"}
                </span>
              </div>
              <CardContent>
                <h2 className="min-h-14 text-lg font-black leading-7 text-white">
                  {bike.model}
                </h2>
                <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <dt className="text-garage-steel">年式</dt>
                    <dd className="mt-1 font-bold text-garage-ivory">
                      {bike.year}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-garage-steel">走行距離</dt>
                    <dd className="mt-1 font-bold text-garage-ivory">
                      {bike.mileage}
                    </dd>
                  </div>
                </dl>
                <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4">
                  <p className="text-2xl font-black text-garage-gold">
                    {bike.price}
                  </p>
                  <BadgeCheck className="h-5 w-5 text-garage-steel" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8">
          <Link href="/" className={buttonClassName({ variant: "outline" })}>
            トップに戻る
          </Link>
        </div>
      </section>
    </main>
  );
}
