import Link from "next/link";
import { ArrowRight, Bike, Gauge, Trophy } from "lucide-react";
import { BrandHeader } from "@/components/brand-header";
import { buttonClassName } from "@/components/ui/button";

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-5">
      <BrandHeader />
      <section className="flex flex-1 flex-col justify-center pb-10">
        <div className="mb-10 border-l border-garage-gold/70 pl-5">
          <p className="mb-4 inline-flex items-center gap-2 text-xs font-bold tracking-[0.22em] text-garage-gold">
            <Bike className="h-4 w-4" />
            CONSIGNMENT SALE
          </p>
          <h1 className="text-4xl font-black leading-tight tracking-normal text-white sm:text-6xl">
            愛車、買取価格で売ってませんか？
          </h1>
          <p className="mt-6 text-base leading-8 text-garage-steel sm:text-lg">
            URUNABIは、THE RUSTY GARAGEが運営するバイク委託販売サポートアプリです。
          </p>
        </div>

        <div className="space-y-4">
          <Link href="/assessment" className={buttonClassName({ className: "gap-3" })}>
            無料で査定する
            <ArrowRight className="h-5 w-5" />
          </Link>
          <Link
            href="/bikes"
            className={buttonClassName({ variant: "outline", className: "gap-3" })}
          >
            委託販売中のバイクを見る
            <Gauge className="h-5 w-5" />
          </Link>
          <Link
            href="/sales"
            className={buttonClassName({ variant: "outline", className: "gap-3" })}
          >
            売却実績を見る
            <Trophy className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </main>
  );
}
