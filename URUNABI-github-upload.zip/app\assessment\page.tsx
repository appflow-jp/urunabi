"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Camera, Send } from "lucide-react";
import { BrandHeader } from "@/components/brand-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const fields = [
  { id: "model", label: "車種", placeholder: "例：Harley-Davidson XL1200X" },
  { id: "year", label: "年式", placeholder: "例：2019年", type: "text" },
  { id: "mileage", label: "走行距離", placeholder: "例：12,000km" },
  { id: "custom", label: "カスタム内容", placeholder: "例：マフラー、シート、外装" },
  { id: "price", label: "希望売却価格", placeholder: "例：650,000円" }
];

export default function AssessmentPage() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);
    setSubmitError("");
    const formData = new FormData(event.currentTarget);
    const params = new URLSearchParams();
    const payload: Record<string, string> = {};

    for (const key of ["model", "year", "mileage", "custom", "price"]) {
      const value = formData.get(key);
      if (typeof value === "string") {
        params.set(key, value);
        payload[key] = value;
      }
    }

    try {
      const response = await fetch("/api/assessment-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error("mail_failed");
      }

      router.push(`/assessment/result?${params.toString()}`);
    } catch {
      setSubmitError(
        "送信設定が未完了のため、メール送信に失敗しました。管理者設定後にもう一度お試しください。"
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="mx-auto min-h-screen w-full max-w-2xl px-5 pb-10">
      <BrandHeader />
      <section>
        <div className="mb-7">
          <p className="text-xs font-bold tracking-[0.22em] text-garage-gold">
            FREE ASSESSMENT
          </p>
          <h1 className="mt-3 text-3xl font-black text-white">無料査定フォーム</h1>
          <p className="mt-3 leading-7 text-garage-steel">
            売却予定のバイク情報を入力してください。MVPでは送信後にモック査定結果を表示します。
          </p>
        </div>

        <Card>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              {fields.map((field) => (
                <label key={field.id} className="block">
                  <span className="mb-2 block text-sm font-bold text-garage-ivory">
                    {field.label}
                  </span>
                  <Input
                    name={field.id}
                    type={field.type ?? "text"}
                    placeholder={field.placeholder}
                    required={field.id !== "custom"}
                  />
                </label>
              ))}

              <label className="block">
                <span className="mb-2 flex items-center gap-2 text-sm font-bold text-garage-ivory">
                  <Camera className="h-4 w-4 text-garage-gold" />
                  写真アップロード
                </span>
                <Input name="photo" type="file" accept="image/*" />
              </label>

              {submitError ? (
                <p className="rounded-md border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm leading-6 text-red-100">
                  {submitError}
                </p>
              ) : null}

              <Button type="submit" className="mt-3 gap-3" disabled={isSubmitting}>
                {isSubmitting ? "送信中..." : "査定結果を見る"}
                <Send className="h-5 w-5" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
