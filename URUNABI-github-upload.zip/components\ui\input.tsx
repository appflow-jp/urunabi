import * as React from "react";
import { cn } from "@/lib/utils";

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        "min-h-13 w-full rounded-md border border-white/12 bg-black/35 px-4 py-3 text-base text-garage-ivory outline-none transition placeholder:text-white/35 focus:border-garage-gold/70 focus:ring-2 focus:ring-garage-gold/20",
        className
      )}
      {...props}
    />
  )
);
Input.displayName = "Input";
