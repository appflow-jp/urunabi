import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        garage: {
          black: "#050505",
          charcoal: "#101010",
          graphite: "#1a1a1a",
          steel: "#a8a29e",
          ivory: "#f5f0e8",
          brass: "#c7a45d",
          gold: "#e1bd72"
        }
      },
      boxShadow: {
        glow: "0 0 60px rgba(199, 164, 93, 0.12)"
      }
    }
  },
  plugins: []
};

export default config;
